#!/bin/sh

#libtoolize --force --copy --automake
#aclocal
#autoheader
#automake --foreign --copy --add-missing
#autoconf

./configure \
    --host=aarch64-linux-gnu	\
    --prefix=/usr/local/arm64/alsa	\
    CC=/usr/local/arm64/gcc-linaro-12.1.1-2022.08-x86_64_aarch64-linux-gnu/bin/aarch64-linux-gnu-gcc	\
    CXX=/usr/local/arm64/gcc-linaro-12.1.1-2022.08-x86_64_aarch64-linux-gnu/bin/aarch64-linux-gnu-g++	\
    AR=/usr/local/arm64/gcc-linaro-12.1.1-2022.08-x86_64_aarch64-linux-gnu/bin/aarch64-linux-gnu-ar	\
    RANLIB=/usr/local/arm64/gcc-linaro-12.1.1-2022.08-x86_64_aarch64-linux-gnu/bin/aarch64-linux-gnu-ranlib	\
    --enable-shared=no	\
    --enable-static=yes


#make
#sudo make install

#--prefix=$PWD/target	\
