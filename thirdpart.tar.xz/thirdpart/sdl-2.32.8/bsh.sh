#!/bin/sh

./configure \
    --host=aarch64-linux-gnu	\
    --prefix=$PWD/target	\
	CC=/usr/local/arm64/gcc-linaro-12.1.1-2022.08-x86_64_aarch64-linux-gnu/bin/aarch64-linux-gnu-gcc	\
	CXX=/usr/local/arm64/gcc-linaro-12.1.1-2022.08-x86_64_aarch64-linux-gnu/bin/aarch64-linux-gnu-g++	\
	CFLAGS="-I./thirdpart/include"	\
	LDFLAGS="-L./thirdpart/lib -lasound -latopology -lx264 -lz"	\
	--disable-shared	\
	--enable-static	\
	--disable-video-x11	\
	--disable-video-opengl	\
	--disable-video-opengles	\
	--enable-alsa	\
	--disable-pulseaudio	\
	--disable-sndio


#make
#make install

#	--enable-shared	\
#	--enable-static	\
#	--disable-video-x11	\
#	--enable-video-fbdev	\
#	--enable-video-opengles	\
#	--enable-video-wayland	\

#	--disable-video-x11	\
#	--disable-video-opengl	\
#	--disable-video-opengles	\
#	--disable-sndio	\
#	--enable-alsa	\
#	--enable-pulseaudio	\
#	cflags='-I./thirdpart/include'	\
#	ldflags='-L./thirdpart/lib -lz -lasound -latopology'
#   --disable-libsamplerate	\
