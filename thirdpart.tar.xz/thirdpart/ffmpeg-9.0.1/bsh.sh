#!/bin/sh

#sudo apt install yasm nasm libx264-dev libx265-dev libvpx-dev libfdk-aac-dev libmp3lame-dev libopus-dev

./configure \
	--enable-cross-compile	\
	--target-os=linux	\
	--arch=aarch64	\
	--cross-prefix=/usr/local/arm64/gcc-linaro-12.1.1-2022.08-x86_64_aarch64-linux-gnu/bin/aarch64-linux-gnu-	\
	--cc=/usr/local/arm64/gcc-linaro-12.1.1-2022.08-x86_64_aarch64-linux-gnu/bin/aarch64-linux-gnu-gcc	\
	--cxx=/usr/local/arm64/gcc-linaro-12.1.1-2022.08-x86_64_aarch64-linux-gnu/bin/aarch64-linux-gnu-g++	\
	--prefix=/home/yulee/arm64	\
	--disable-asm	\
	--enable-shared	\
	--enable-static	\
	--extra-cflags='-I./thirdpart/include'	\
	--extra-ldflags='-L./thirdpart/lib -lz'	\
	--pkg-config=PKGCONFIG	\
	--enable-gpl	\
	--enable-nonfree	\
	--enable-avcodec	\
	--enable-avformat	\
	--enable-avutil		\
	--enable-swresample	\
	--enable-swscale	\
	--enable-avfilter	\
	--enable-decoders	\
	--enable-encoders	\
	--enable-demuxers	\
	--enable-parsers	\
	--enable-zlib
#make
#make install

