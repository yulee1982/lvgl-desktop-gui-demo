#!/bin/sh

#cross_compile_prefix=/usr/local/arm64/gcc-linaro-12.1.1-2022.08-x86_64_aarch64-linux-gnu/bin/aarch64-linux-gnu-
cross_compile_prefix=aarch64-linux-gnu-
export AR="$cross_compile_prefix"ar
export AS="$cross_compile_prefix"as
export LD="$cross_compile_prefix"ld
export RANLIB="$cross_compile_prefix"ranlib
export CC="$cross_compile_prefix"gcc
export NM="$cross_compile_prefix"nm

./configure --prefix="$PWD/target" -static
make
make install
